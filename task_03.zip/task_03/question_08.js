document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("action").addEventListener("click", showPopup);
});

function showPopup() {
  alert("Why did you do that?");
}
